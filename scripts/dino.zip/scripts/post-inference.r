library(RevGadgets)
file <- "output/Palss_2024_dino_mcc.tre"
FBD_tree <- RevGadgets::readTrees(paths = file)

## add the offset back to our posterior

FBD_tree[[1]][[1]]@data[["age_0.95_HPD"]]<- 
  lapply(FBD_tree[[1]][[1]]@data[["age_0.95_HPD"]], function(x) x + 98)


color <- adjustcolor( "blue", alpha.f = 0.1)

# create the plot of the rooted tree
p <- plotFBDTree(tree = FBD_tree, 
            timeline = T, 
            geo_units = "epochs",
            tip_labels_italics = T,
            tip_labels_remove_underscore = T,
            tip_labels_size = 1, 
            tip_age_bars = T,
            node_age_bars = T,
            age_bars_color = color,
            label_sampled_ancs = TRUE,
            line_width = 0.5,
            age_bars_width = 0.5)



## add the offset back to the tree!
p$data$x <- p$data$x - 98

# plot
p

