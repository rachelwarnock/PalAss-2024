## read in the fossil ages

taxa_ages <- read.table("data/2unique_ages.csv", header = T)
rownames(unique_taxa_ages) <- unique_taxa_ages[,1]
dinoRanges <- unique_taxa_ages[,2:3]



#### randomly resolve polytomies on the tree
phy <- ape::read.tree("data/dino.tree")

## code taken from http://blog.phytools.org/2017/06/generating-set-of-random-resolutions-of.html
resolveRandom<-function(tree){
  while(!is.binary(tree)){
    nodes<-1:tree$Nnode+Ntip(tree)
    Nchildren<-function(node,tree) length(Children(tree,node))
    nchilds<-sapply(nodes,Nchildren,tree=tree)
    node<-nodes[which(nchilds>2)[1]]
    tree<-sample(resolveNode(tree,node),1)[[1]]
  }
  tree
}


Binary_tree <- resolveRandom(phy)

## timescale the trees 

tt_polytomy <- paleotree::timePaleoPhy(tree = phy, timeData = dinoRanges, type = "mbl", randres = FALSE,
                                       ntrees = 1, plot= T, vartime = 2)


tt_binary <-  paleotree::timePaleoPhy(tree = Binary_tree, timeData = dinoRanges, type = "mbl", randres = FALSE,
                                      ntrees = 1, plot = T, vartime = 2)




## write them to file
write.tree(tt_polytomy,"data/dated_backbone.tre")
write.tree(tt_binary,"data/dated_initial.tre")

